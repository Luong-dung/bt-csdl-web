'use strict';
const $=id=>document.getElementById(id);
const sample=[
  {id:'SV001',hoTen:'Lường Tiến Dũng',tuoi:20,email:'dung@example.com'},
  {id:'SV002',hoTen:'Đồng Đức Dương',tuoi:19,email:'ducduong@example.com'},
  {id:'SV003',hoTen:'Nguyễn Quốc Doanh',tuoi:21,email:'doanh@example.com'},
  {id:'SV004',hoTen:'Nguyễn Tùng Dương',tuoi:20,email:'tungduong@example.com'}
];
let students=[];
const escapeXml=s=>String(s).replace(/[<>&"']/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&apos;'}[c]));
function toXml(rows){return '<?xml version="1.0" encoding="UTF-8"?>\n<danhSachSinhVien>\n'+rows.map(s=>`  <sinhVien id="${escapeXml(s.id)}">\n    <hoTen>${escapeXml(s.hoTen)}</hoTen>\n    <tuoi>${s.tuoi}</tuoi>\n    <email>${escapeXml(s.email)}</email>\n  </sinhVien>`).join('\n')+'\n</danhSachSinhVien>';}
function validate(rows){
  if(!Array.isArray(rows)) throw Error('Cấu trúc: sinhVien phải là một mảng.');
  const ids=new Set();
  rows.forEach((s,i)=>{
    if(!s||typeof s!=='object'||Array.isArray(s)) throw Error(`Sinh viên ${i+1}: cần một object.`);
    for(const k of ['id','hoTen','email']) if(typeof s[k]!=='string'||!s[k].trim()) throw Error(`Sinh viên ${i+1}: ${k} phải là chuỗi không rỗng.`);
    if(!Number.isSafeInteger(s.tuoi)||s.tuoi<0) throw Error(`Sinh viên ${i+1}: tuoi phải là số nguyên không âm.`);
    if(ids.has(s.id)) throw Error(`Mã sinh viên bị trùng: ${s.id}`);
    ids.add(s.id);
  });
  return rows;
}
function xmlDocument(){
  const text=$('xml').value;
  if(/<!DOCTYPE/i.test(text)) throw Error('Demo không hỗ trợ DOCTYPE/DTD. Hãy dùng XML mẫu không có DTD.');
  const doc=new DOMParser().parseFromString(text,'application/xml');
  if(doc.getElementsByTagName('parsererror').length) throw Error('Sai cú pháp XML: '+doc.getElementsByTagName('parsererror')[0].textContent.trim());
  return doc;
}
function parseXml(){
  const doc=xmlDocument(),root=doc.documentElement;
  if(root.tagName!=='danhSachSinhVien') throw Error('Đúng cú pháp XML, nhưng root phải là danhSachSinhVien.');
  const rows=Array.from(root.children).map(n=>{
    if(n.tagName!=='sinhVien') throw Error('Cấu trúc: root chỉ chứa các phần tử sinhVien.');
    const fields=Array.from(n.children);
    if(fields.length!==3||fields.some((f,i)=>f.tagName!==['hoTen','tuoi','email'][i]||f.children.length)) throw Error('Mỗi sinhVien cần đúng hoTen, tuoi, email theo thứ tự, chứa văn bản.');
    const age=fields[1].textContent.trim();
    if(!/^\d+$/.test(age)) throw Error('Đúng cú pháp XML, nhưng tuoi phải là số nguyên không âm.');
    return {id:n.getAttribute('id'),hoTen:fields[0].textContent,tuoi:Number(age),email:fields[2].textContent};
  });
  return validate(rows);
}
function parseJson(){
  let data;
  try{data=JSON.parse($('json').value);}catch(e){throw Error('Sai cú pháp JSON: '+e.message);}
  return validate(data?.sinhVien);
}
function status(id,message,ok=true){const el=$(id);el.textContent=message;el.className='status '+(ok?'success':'error');}
function render(rows,source){
  students=rows.map(s=>({...s}));$('students').replaceChildren();
  students.forEach((s,i)=>{
    const tr=document.createElement('tr');
    [s.id,s.hoTen,s.tuoi,s.email].forEach((v,j)=>{
      const td=document.createElement('td');
      if(j===2){const input=document.createElement('input');input.type='number';input.min='0';input.step='1';input.value=v;input.setAttribute('aria-label','Tuổi của '+s.hoTen);input.addEventListener('input',()=>{students[i].tuoi=input.value.trim()===''?NaN:Number(input.value);status('table-status','Bảng đã sửa. Bấm Xuất bảng để cập nhật hai ô dữ liệu.');});td.append(input);}else td.textContent=v;
      tr.append(td);
    });$('students').append(tr);
  });
  $('source').textContent='Nguồn: '+source;$('count').textContent=rows.length+' sinh viên';status('table-status','Đã đọc dữ liệu thành công.');
}
function read(kind,convert=false){
  try{
    const rows=kind==='xml'?parseXml():parseJson();
    if(convert){if(kind==='xml') $('json').value=JSON.stringify({sinhVien:rows},null,2);else $('xml').value=toXml(rows);status((kind==='xml'?'json':'xml')+'-status','Đã chuyển đổi theo cấu trúc sinh viên của demo.');}
    render(rows,kind.toUpperCase());status(kind+'-status',`✓ Đúng cú pháp và cấu trúc demo · ${rows.length} sinh viên`);
  }catch(e){status(kind+'-status',e.message,false);}
}
function reset(){
  $('xml').value=toXml(sample);$('json').value=JSON.stringify({sinhVien:sample},null,2);
  for(const kind of ['xml','json']) status(kind+'-status','Dữ liệu mẫu · Sẵn sàng kiểm tra');
  $('xpath').value='/danhSachSinhVien/sinhVien[tuoi>=20]/hoTen';$('xpath-result').textContent='Bấm Chạy để xem kết quả.';render(sample,'Mẫu');
}
document.querySelectorAll('[data-read]').forEach(b=>b.onclick=()=>read(b.dataset.read));
document.querySelectorAll('[data-error]').forEach(b=>b.onclick=()=>{
  const kind=b.dataset.error;
  if(kind==='xml') $('xml').value=toXml(sample).replace('</hoTen>','</ten>');
  else $('json').value=JSON.stringify({sinhVien:sample},null,2).replace(/\}\s*$/,',\n}');
  status(kind+'-status','Đã nạp ví dụ lỗi. Bấm nút kiểm tra để xem parser báo lỗi.',false);
});
for(const kind of ['xml','json']) $(kind).addEventListener('input',()=>status(kind+'-status','Nội dung đã thay đổi · Chưa kiểm tra'));
$('reset').onclick=reset;$('to-json').onclick=()=>read('xml',true);$('to-xml').onclick=()=>read('json',true);
$('export').onclick=()=>{try{validate(students);$('json').value=JSON.stringify({sinhVien:students},null,2);$('xml').value=toXml(students);for(const k of ['xml','json']) status(k+'-status','Đã xuất từ bảng · Đúng cấu trúc demo');$('source').textContent='Nguồn: Bảng đã xuất';status('table-status','✓ Đã xuất bảng sang cả XML và JSON.');}catch(e){status('table-status',e.message,false);}};
$('run-xpath').onclick=()=>{
  try{
    const doc=xmlDocument();const result=doc.evaluate($('xpath').value,doc,null,XPathResult.ANY_TYPE,null);
    let text;
    if(result.resultType===XPathResult.NUMBER_TYPE) text=String(result.numberValue);
    else if(result.resultType===XPathResult.STRING_TYPE) text=result.stringValue;
    else if(result.resultType===XPathResult.BOOLEAN_TYPE) text=String(result.booleanValue);
    else{const values=[];let n;while((n=result.iterateNext())) values.push(n.textContent);text=values.length?values.map((v,i)=>`${i+1}. ${v}`).join('\n'):'Không có node phù hợp.';}
    $('xpath-result').textContent=text;
  }catch(e){$('xpath-result').textContent='Lỗi: '+e.message;}
};
document.querySelectorAll('[data-xpath]').forEach(b=>b.onclick=()=>{$('xpath').value=b.dataset.xpath;$('run-xpath').click();});
reset();

for $sv in doc("sinh-vien.xml")/danhSachSinhVien/sinhVien
where xs:integer($sv/tuoi) >= 20
order by xs:integer($sv/tuoi) descending, string($sv/@id)
return
  <ketQua ma="{data($sv/@id)}">
    {$sv/hoTen}
    {$sv/tuoi}
  </ketQua>

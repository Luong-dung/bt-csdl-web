"""Verify report examples outside the browser demo; requires lxml."""
from pathlib import Path
from copy import deepcopy
from lxml import etree
import json

root=Path(__file__).parent
doc=etree.parse(str(root/'sinh-vien.xml'))
dtd=etree.DTD(str(root/'sinh-vien.dtd'))
schema=etree.XMLSchema(etree.parse(str(root/'sinh-vien.xsd')))
results=[]
def check(name,condition):
    assert condition,name
    results.append({'case':name,'result':'PASS'})
check('DTD: valid sample',dtd.validate(doc))
check('XSD: valid sample',schema.validate(doc))
bad=deepcopy(doc);bad.find('.//tuoi').text='hai muoi'
check('DTD allows textual age',dtd.validate(bad))
check('XSD rejects textual age',not schema.validate(bad))
bad=deepcopy(doc);bad.find('.//tuoi').text='-1'
check('XSD rejects negative age',not schema.validate(bad))
bad=deepcopy(doc);bad.find('.//sinhVien').remove(bad.find('.//email'))
check('DTD rejects missing email',not dtd.validate(bad))
check('XSD rejects missing email',not schema.validate(bad))
bad=deepcopy(doc);bad.findall('.//sinhVien')[1].set('id','SV001')
check('DTD rejects duplicate ID',not dtd.validate(bad))
check('XSD rejects duplicate ID',not schema.validate(bad))
check('XPath: 4 students',doc.xpath('count(/danhSachSinhVien/sinhVien)')==4)
names=doc.xpath('/danhSachSinhVien/sinhVien[tuoi>=20]/hoTen/text()')
check('XPath: age >=20',names==['Lường Tiến Dũng','Nguyễn Quốc Doanh','Nguyễn Tùng Dương'])
check('XPath: age >=21',doc.xpath('/danhSachSinhVien/sinhVien[tuoi>=21]/@id')==['SV003'])
transform=etree.XSLT(etree.parse(str(root/'sinh-vien.xsl')))
html=transform(doc)
check('XSLT: filter and numeric sort',html.xpath('//tr/td[1]/text()')==['SV003','SV001','SV004'])
(root/'ket-qua-xslt.html').write_bytes(etree.tostring(html,method='html',encoding='utf-8'))
(root/'ket-qua-kiem-tra.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print(f'{len(results)} checks passed (lxml {etree.LXML_VERSION})')

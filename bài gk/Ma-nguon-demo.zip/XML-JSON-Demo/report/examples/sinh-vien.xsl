<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:output method="html" encoding="UTF-8"/>
  <xsl:template match="/">
    <html lang="vi">
      <head><title>Sinh viên từ 20 tuổi</title></head>
      <body>
        <h1>Sinh viên từ 20 tuổi</h1>
        <table border="1">
          <tr><th>Mã</th><th>Họ tên</th><th>Tuổi</th></tr>
          <xsl:for-each
            select="danhSachSinhVien/sinhVien[tuoi &gt;= 20]">
            <xsl:sort select="tuoi" data-type="number"
                      order="descending"/>
            <tr>
              <td><xsl:value-of select="@id"/></td>
              <td><xsl:value-of select="hoTen"/></td>
              <td><xsl:value-of select="tuoi"/></td>
            </tr>
          </xsl:for-each>
        </table>
      </body>
    </html>
  </xsl:template>
</xsl:stylesheet>

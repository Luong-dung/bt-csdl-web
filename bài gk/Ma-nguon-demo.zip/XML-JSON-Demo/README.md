# Demo XML & JSON — MAT3385

## Mở demo

Giải nén toàn bộ ZIP rồi mở index.html bằng Chrome, Edge hoặc Firefox.
Trang web không cần cài thư viện, backend hoặc kết nối mạng.

Nếu muốn dùng localhost, mở terminal tại thư mục XML-JSON-Demo:

```text
python -m http.server 8000
```

Truy cập http://localhost:8000. Nhấn Ctrl+C để dừng server.

## Các thao tác minh họa

1. Đọc XML và JSON mẫu thành cùng một bảng sinh viên.
2. Bấm Tạo lỗi thử rồi kiểm tra; bấm Khôi phục mẫu để quay lại.
3. Chạy XPath để lọc tên theo tuổi hoặc đếm sinh viên.
4. Sửa tuổi trong bảng rồi xuất lại XML và JSON.
5. Chuyển đổi giữa hai định dạng theo mô hình sinh viên của demo.

Tuổi và email là dữ liệu minh họa. Trang không lưu dữ liệu qua lần tải lại.
Kiểm tra cấu trúc trên trang dùng JavaScript, không phải DTD/XSD.

## Bộ ví dụ bổ sung trong report/examples

XML, DTD, XSD, XSLT và XQuery đi kèm minh họa phần lý thuyết của báo cáo.
XQuery là ví dụ nguồn chưa thực thi; không nhập vào ô XPath của trang.

Chương trình kiểm tra riêng cần Python và lxml. Chạy từ XML-JSON-Demo:

```text
python -m pip install -r requirements.txt
python report/examples/check_examples.py
```

13 kiểm tra DTD/XSD/XPath/XSLT đã chạy đạt với lxml 6.1.3.
Kết quả nằm ở ket-qua-kiem-tra.json và ket-qua-xslt.html trong examples.
Các kiểm tra này không thay thế kiểm thử tương tác trên trình duyệt.
